import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { StepProgress } from './components/StepProgress';
import { ChatArea } from './components/ChatArea';
import { UploadArea } from './components/UploadArea';
import { AnalysisReport } from './components/AnalysisReport';
import { ChatReport } from './components/ChatReport';
import { ChatInput } from './components/ChatInput';
import { LoginPage } from './components/LoginPage';
import { DeleteConfirmDialog } from './components/DeleteConfirmDialog';
import { AnalyzingLoader } from './components/AnalyzingLoader';
import { EmptyState } from './components/EmptyState';
import { MessageList } from './components/MessageList';
import { TypingIndicator } from './components/TypingIndicator';
import { useState, useEffect } from 'react';
import { Toaster } from 'sonner@2.0.3';
import { toast } from 'sonner@2.0.3';
import { generateMockResponse } from './utils/mockAIResponses';

interface InterviewData {
  id: string;
  title: string;
  company: string;
  position: string;
  status: '待上传' | '分析中' | '已完成';
  date: string;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  isStreaming?: boolean;
}

export default function App() {
  // Default demo interviews
  const getDefaultInterviews = (): InterviewData[] => {
    return [
      {
        id: '1',
        title: '未命名面试 48',
        company: '未知公司',
        position: '未知岗位',
        status: '待上传',
        date: '2025-12-08T14:30',
      },
      {
        id: '2',
        title: '字节跳动前端一面',
        company: '字节跳动',
        position: '前端开发工程师',
        status: '已完成',
        date: '2024-03-15T14:00',
      },
      {
        id: '3',
        title: '腾讯技术面',
        company: '腾讯',
        position: '后端开发',
        status: '已完成',
        date: '2025-12-03T10:30',
      },
      {
        id: '4',
        title: '阿里巴巴二面',
        company: '阿里巴巴',
        position: '算法工程师',
        status: '已完成',
        date: '2025-12-01T16:00',
      },
    ];
  };

  // Login state - Load from localStorage
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    const saved = localStorage.getItem('interreview_isLoggedIn');
    return saved === 'true';
  });
  const [currentUser, setCurrentUser] = useState(() => {
    return localStorage.getItem('interreview_currentUser') || '';
  });

  // Toggle between upload view and analysis report view
  const [viewMode, setViewMode] = useState<'upload' | 'report'>('report');
  const [currentStep, setCurrentStep] = useState(3);
  const [selectedInterviewId, setSelectedInterviewId] = useState('2');
  
  // Delete confirmation dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [interviewToDelete, setInterviewToDelete] = useState<InterviewData | null>(null);
  
  // Chat messages state - separate messages for each interview
  const [interviewMessages, setInterviewMessages] = useState<Record<string, Message[]>>({});
  const [isAITyping, setIsAITyping] = useState(false);
  
  // Interview data state - Load from localStorage
  const [interviews, setInterviews] = useState<InterviewData[]>(() => {
    const savedUser = localStorage.getItem('interreview_currentUser');
    if (!savedUser) return getDefaultInterviews();
    
    const saved = localStorage.getItem(`interreview_interviews_${savedUser}`);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved interviews:', e);
        return getDefaultInterviews();
      }
    }
    
    // First time user - return default demo data
    return getDefaultInterviews();
  });

  // Get current interview
  const currentInterview = interviews.find(i => i.id === selectedInterviewId);

  // Persist login state and user to localStorage
  useEffect(() => {
    if (isLoggedIn && currentUser) {
      localStorage.setItem('interreview_isLoggedIn', 'true');
      localStorage.setItem('interreview_currentUser', currentUser);
    }
  }, [isLoggedIn, currentUser]);

  // Persist interviews data to localStorage
  useEffect(() => {
    if (currentUser && interviews.length > 0) {
      localStorage.setItem(`interreview_interviews_${currentUser}`, JSON.stringify(interviews));
    }
  }, [interviews, currentUser]);

  // Update interview data
  const updateInterview = (id: string, data: Partial<InterviewData>) => {
    setInterviews(prev => prev.map(interview => 
      interview.id === id ? { ...interview, ...data } : interview
    ));
  };

  // Rename interview
  const renameInterview = (id: string, newTitle: string) => {
    const oldTitle = interviews.find(i => i.id === id)?.title;
    updateInterview(id, { title: newTitle });
    toast.success(`已重命名为「${newTitle}」`);
  };

  // Show delete confirmation dialog
  const showDeleteDialog = (id: string) => {
    const interview = interviews.find(i => i.id === id);
    if (!interview) return;
    
    // Check if trying to delete an interview that is being analyzed
    if (interview.status === '分析中') {
      toast.error('该面试正在分析中，无法删除', {
        description: '请等待分析完成后再删除',
      });
      return;
    }
    
    setInterviewToDelete(interview);
    setDeleteDialogOpen(true);
  };

  // Confirm delete interview
  const confirmDeleteInterview = () => {
    if (!interviewToDelete) return;
    
    const id = interviewToDelete.id;
    const title = interviewToDelete.title;

    // If deleting the currently selected interview, select another one
    if (id === selectedInterviewId) {
      const remainingInterviews = interviews.filter(i => i.id !== id);
      if (remainingInterviews.length > 0) {
        const nextInterview = remainingInterviews[0];
        setSelectedInterviewId(nextInterview.id);
        setViewMode(nextInterview.status === '已完成' ? 'report' : 'upload');
        setCurrentStep(nextInterview.status === '已完成' ? 3 : 2);
      }
    }

    // Remove the interview
    setInterviews(prev => prev.filter(interview => interview.id !== id));
    
    // Close dialog and reset state
    setDeleteDialogOpen(false);
    setInterviewToDelete(null);
    
    // Show success toast
    toast.success(`已删除「${title}」`);
  };

  // Delete interview (old function - keep for backward compatibility)
  const deleteInterview = (id: string) => {
    showDeleteDialog(id);
  };

  // Create new interview
  const createNewInterview = () => {
    // Generate new ID
    const newId = Date.now().toString();
    
    // Generate interview number based on existing interviews
    const existingNumbers = interviews
      .map(i => {
        const match = i.title.match(/未命名面试 (\d+)/);
        return match ? parseInt(match[1]) : 0;
      })
      .filter(n => n > 0);
    
    const nextNumber = existingNumbers.length > 0 ? Math.max(...existingNumbers) + 1 : 1;
    
    // Get current date and time
    const now = new Date();
    const dateTimeString = now.toISOString().slice(0, 16); // Format: YYYY-MM-DDTHH:mm
    
    // Create new interview
    const newInterview: InterviewData = {
      id: newId,
      title: `未命名面试 ${nextNumber}`,
      company: '未知公司',
      position: '未知岗位',
      status: '待上传',
      date: dateTimeString,
    };
    
    // Add to interviews list (add to the beginning)
    setInterviews(prev => [newInterview, ...prev]);
    
    // Select the new interview and switch to upload view
    setSelectedInterviewId(newId);
    setViewMode('upload');
    setCurrentStep(1);
    
    // Show success toast
    toast.success(`面试分析 #${nextNumber} 已创建`);
  };

  // Handle file upload complete
  const handleUploadComplete = (file: File) => {
    // Update current step to show file is uploaded
    setCurrentStep(2);
    console.log('File uploaded:', file.name);
  };

  // Handle start analysis
  const handleStartAnalysis = () => {
    // Update interview status to "分析中"
    updateInterview(selectedInterviewId, { status: '分析中' });
    setCurrentStep(3);
    
    toast.success('开始分析面试内容...', {
      description: '预计需要 30-60 秒',
    });

    // Simulate analysis process (10 seconds)
    setTimeout(() => {
      // Update interview status to "已完成"
      updateInterview(selectedInterviewId, { status: '已完成' });
      setViewMode('report');
      
      toast.success('分析完成！', {
        description: '面试报告已生成',
      });
    }, 10000); // 10 seconds to match the loader animation
  };

  // Get interview name for header
  const getInterviewName = () => {
    return currentInterview?.title || '未命名面试';
  };

  // Handle login
  const handleLogin = (username: string) => {
    setCurrentUser(username);
    setIsLoggedIn(true);
    localStorage.setItem('interreview_isLoggedIn', 'true');
    localStorage.setItem('interreview_currentUser', username);
  };

  // Handle logout
  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser('');
    localStorage.removeItem('interreview_isLoggedIn');
    localStorage.removeItem('interreview_currentUser');
  };

  // Handle send message
  const handleSendMessage = (content: string) => {
    if (!selectedInterviewId || isAITyping) return;

    // Create user message
    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date().toISOString(),
    };

    // Add user message to current interview's messages
    setInterviewMessages(prev => ({
      ...prev,
      [selectedInterviewId]: [...(prev[selectedInterviewId] || []), userMessage],
    }));

    // Show AI typing indicator
    setIsAITyping(true);

    // Simulate AI thinking time (1-2 seconds)
    setTimeout(() => {
      // Generate AI response
      const aiResponse = generateMockResponse(content);
      
      // Create AI message with streaming flag
      const aiMessage: Message = {
        id: `msg-${Date.now()}-ai`,
        role: 'assistant',
        content: aiResponse,
        timestamp: new Date().toISOString(),
        isStreaming: true,
      };

      // Add AI message
      setInterviewMessages(prev => ({
        ...prev,
        [selectedInterviewId]: [...(prev[selectedInterviewId] || []), aiMessage],
      }));

      // Hide typing indicator
      setIsAITyping(false);

      // Remove streaming flag after typing animation completes
      // Approximate time: 20ms per character
      const typingDuration = aiResponse.length * 20;
      setTimeout(() => {
        setInterviewMessages(prev => ({
          ...prev,
          [selectedInterviewId]: prev[selectedInterviewId].map(msg =>
            msg.id === aiMessage.id ? { ...msg, isStreaming: false } : msg
          ),
        }));
      }, typingDuration);
    }, 1000 + Math.random() * 1000); // Random delay between 1-2 seconds
  };

  // Get current interview messages
  const currentMessages = interviewMessages[selectedInterviewId] || [];

  // Show login page if not logged in
  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Toast Notification Container */}
      <Toaster position="top-center" richColors />
      
      {/* Delete Confirmation Dialog */}
      <DeleteConfirmDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        interview={interviewToDelete}
        onConfirm={confirmDeleteInterview}
      />
      
      {/* Left Sidebar */}
      <Sidebar 
        interviews={interviews}
        selectedInterviewId={selectedInterviewId}
        onInterviewSelect={(id, mode) => {
          setSelectedInterviewId(id);
          setViewMode(mode);
          setCurrentStep(mode === 'upload' ? 2 : 3);
        }}
        onInterviewRename={renameInterview}
        onInterviewDelete={deleteInterview}
        onCreateNewInterview={createNewInterview}
        currentUser={currentUser}
        onLogout={handleLogout}
      />
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header Bar */}
        <Header 
          viewMode={viewMode} 
          interviewName={getInterviewName()}
          onRename={(newName) => renameInterview(selectedInterviewId, newName)}
        />
        
        {/* Main Work Area - Scrollable Content */}
        <div className="flex-1 overflow-y-auto px-8 py-6">
          <div className="max-w-5xl mx-auto space-y-8 pb-32">
            {interviews.length === 0 ? (
              /* Show empty state when no interviews exist */
              <EmptyState onCreateNew={createNewInterview} />
            ) : currentInterview?.status === '分析中' ? (
              /* Show analyzing loader for "分析中" status */
              <AnalyzingLoader interviewName={currentInterview?.title} />
            ) : viewMode === 'upload' ? (
              <>
                {/* Welcome Title */}
                <h1 className="text-center">有什么可以帮忙的？</h1>
                
                {/* Step Progress */}
                <StepProgress currentStep={currentStep} />
                
                {/* Message List */}
                {currentMessages.length > 0 && (
                  <MessageList messages={currentMessages} />
                )}
                
                {/* AI Typing Indicator */}
                {isAITyping && <TypingIndicator />}
                
                {/* Chat Area - Only show if no messages */}
                {currentMessages.length === 0 && <ChatArea onSendMessage={handleSendMessage} disabled={isAITyping} />}
                
                {/* Upload Area */}
                <UploadArea 
                  onUploadComplete={handleUploadComplete} 
                  onStartAnalysis={handleStartAnalysis}
                />
              </>
            ) : (
              <>
                {/* Step Progress */}
                <StepProgress currentStep={currentStep} />
                
                {/* Chat Report - Conversation Style */}
                <ChatReport 
                  interviewData={currentInterview}
                  onUpdateInterview={(data) => updateInterview(selectedInterviewId, data)}
                />
                
                {/* Message List */}
                {currentMessages.length > 0 && (
                  <MessageList messages={currentMessages} />
                )}
                
                {/* AI Typing Indicator */}
                {isAITyping && <TypingIndicator />}
              </>
            )}
          </div>
        </div>
        
        {/* Chat Input - Fixed at Bottom (only show in report view) */}
        {interviews.length > 0 && 
         currentInterview?.status !== '分析中' && 
         viewMode === 'report' && (
          <ChatInput onSendMessage={handleSendMessage} disabled={isAITyping} />
        )}
      </main>
    </div>
  );
}